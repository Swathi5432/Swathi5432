import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AnnualReport } from '../annual-report';
import { AnnualReportService } from '../annual-report.service';

@Component({
  selector: 'app-update-product',
  templateUrl: './update-product.component.html',
  styleUrls: ['./update-product.component.css']
})
export class UpdateProductComponent implements OnInit{
  id:number;
  report:AnnualReport=new AnnualReport();

constructor(private annualReportService:AnnualReportService ,
  private route:ActivatedRoute,
  private router: Router
  ){

}
ngOnInit(): void {
  this.id=this.route.snapshot.params['id'];
  this.annualReportService.getProductById(this.id).subscribe(data =>{
    this.report=data;
  }
  );
}

onSubmit(){
  this.annualReportService.updateProduct(this.id,this.report).subscribe(data =>{
    this.gotoAnnualReportList();

  })
}
gotoAnnualReportList(){
  this.router.navigate(['/reports']);
}
}
