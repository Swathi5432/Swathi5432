export class AnnualReport {
    id: number;
    year: string;
    balance: string;
    income: string;
    sales: string;
    // totalSales:string;
    // totalIncome:string;
    // totalBalance:string;
    product_name:string;
}
